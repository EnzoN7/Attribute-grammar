/**
 * 
 */
package fr.n7.stl.block.ast.expression.value;

import fr.n7.stl.block.ast.expression.Expression;

/**
 * @author Marc Pantel
 *
 */
public interface Value extends Expression {

}
